package com.example.movie_catalog

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
